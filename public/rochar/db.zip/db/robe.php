<?php

/**
* @fileoverview Robe view id
* @author Vincent Thibault (alias KeyWorld - Twitter: @robrowser)
* @version 1.3
*/

return array(
	false,            // none
	array( "name" => "õ�糯��",       "size" => "big"   ), // robe wings
	array( "name" => "���谡�賶",     "size" => "small" ), // bag of adventurer
	array( "name" => "Ÿ��õ���ǳ���", "size" => "big"   )  // robe wings of fallen angel
);
